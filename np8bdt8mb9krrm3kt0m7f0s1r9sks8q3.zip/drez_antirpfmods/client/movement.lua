local function MovementTest()
    local maxSpeed = 0

    RemovePlatformObject("wall")
    AddPlatformObject("stairs")
    Wait(300)

    local playerPed = PlayerPedId()
    local testPosition = Config.MovementTest.Player
    SetEntityCoords(playerPed, testPosition.x, testPosition.y, testPosition.z)
    SetEntityHeading(playerPed, testPosition.w)
    Wait(100)

    local targetPoint = Config.MovementTest.Point
    TaskGoStraightToCoord(playerPed, targetPoint.x, targetPoint.y, targetPoint.z, 15.0, -1, 270.0, 1.0)
    SetRunSprintMultiplierForPlayer(PlayerId(), 1.0)

    while GetScriptTaskStatus(playerPed, 2106541073) == 0 do
        SetRunSprintMultiplierForPlayer(PlayerId(), 1.0)
        Wait(0)
    end

    while GetScriptTaskStatus(playerPed, 2106541073) == 1 do
        Wait(0)
        SetRunSprintMultiplierForPlayer(PlayerId(), 1.0)
        local speed = GetEntitySpeed(playerPed)
        if maxSpeed < speed then
            maxSpeed = speed
        end
        local distance = #(targetPoint - GetEntityCoords(playerPed))
        if distance <= 2.0 then
            break
        end
    end

    ClearPedTasks(playerPed)
    ClearPedTasksImmediately(playerPed)

    local passed = true
    local lowSpeed = maxSpeed < 6.0
    return passed, lowSpeed
end

MovementTest = MovementTest
