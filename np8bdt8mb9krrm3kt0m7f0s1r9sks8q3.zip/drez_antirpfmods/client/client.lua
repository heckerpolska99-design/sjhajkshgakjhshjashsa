local isTestActive, isPlayerReady, isAbortTriggered = false, false, false
local TEST_RUNNING = false

RegisterNetEvent("drez_antirpfmods/syncBucket")
AddEventHandler("drez_antirpfmods/syncBucket", function()
    if GetInvokingResource() ~= nil then return end
    isTestActive = true
end)

RegisterNetEvent("drez_antirpfmods/abort")
AddEventHandler("drez_antirpfmods/abort", function()
    if GetInvokingResource() ~= nil then return end
    isAbortTriggered = true
end)

local function RunAntiRPFTest()
    local originalCoords = GetEntityCoords(PlayerPedId())
    
    if Config.NoRelations then
        Config.SyncHandle()
    end

    TEST_RUNNING = true
    DoScreenFadeOut(0)
    while not IsScreenFadedOut() do Wait(0) end

    TriggerServerEvent("drez_antirpfmods/start")

    while not isTestActive do Wait(0) end
    isTestActive = false

    LoadPlayerDefaultModel()
    SpawnPlatform()
    SetPlayerControl(PlayerId(), false)
    LoadCollisions()
    isPlayerReady = true

    StartAudioScene("MP_LEADERBOARD_SCENE")
    StartAudioScene("MP_LOBBY_SCENE")

    if IsEntityDead(PlayerPedId()) or IsPedFatallyInjured(PlayerPedId()) or GetEntityHealth(PlayerPedId()) == 0 then
        NetworkResurrectLocalPlayer(Config.TestPlace.x, Config.TestPlace.y, Config.TestPlace.z, Config.TestPlace.w, 0, false)
        SetEntityHealth(PlayerPedId(), 200)
    end

    CreateThread(function()
        while isPlayerReady do
            local currentCoords = GetEntityCoords(PlayerPedId())
            local testCoords = vec3(Config.TestPlace.x, Config.TestPlace.y, Config.TestPlace.z)
            if #(currentCoords - testCoords) >= 30.0 then
                TriggerServerEvent("drez_antirpfmods/abort", "Player aborted test RPF Mods with reason: Player got teleported by another source or script " .. tostring(currentCoords))
                break
            end
            Wait(1000)
        end
    end)

    local testResults = {}

    if Config.AntiWeaponComponentsDamage then
        local passed = WeaponComponentsDamageDetection() and "not detected" or "mods detected"
        table.insert(testResults, {name = "Anti-Weapon-Components", passed = passed})
    end

    if Config.AntiNoBushMods then
        local modsDetected = DetectNoBushes() or false
        local passed = modsDetected == false and "not detected" or "mods detected (" .. modsDetected .. ")"
        table.insert(testResults, {name = "Anti-No-Bushes", passed = passed})
    end

    if Config.AntiNoWaterMods then
        local hasWater = DoesPlayerHaveWater()
        local passed = hasWater and "not detected" or "mods detected"
        table.insert(testResults, {name = "Anti-No-Water", passed = passed})
    end

    if Config.AntiQuickSeat then
        local success, reason = QuickSeatMods()
        if not success then
            TriggerServerEvent("drez_antirpfmods/abort", "Player aborted test Anti-Quick-Seat with reason: " .. tostring(reason))
        else
            table.insert(testResults, {name = "Anti-Quick-Seat", passed = reason and "not detected" or "mods detected"})
        end
    end

    if Config.AntiQuickReload then
        local success, reason = QuickReloadMods()
        if not success then
            TriggerServerEvent("drez_antirpfmods/abort", "Player aborted test Anti-Quick-Reload with reason: " .. tostring(reason))
        else
            table.insert(testResults, {name = "Anti-Quick-Reload", passed = reason and "not detected" or "mods detected"})
        end
    end

    if Config.AntiBulletPenetration then
        local success, reason = BulletPenTest()
        if not success then
            TriggerServerEvent("drez_antirpfmods/abort", "Player aborted test Anti-Bullet-Penetration with reason: " .. tostring(reason))
        else
            table.insert(testResults, {name = "Anti-Bullet-Penetration-" .. (type(success) == "string" and success or "All"), passed = reason and "not detected" or "mods detected"})
        end
    end

    if Config.AntiMovementMods then
        local success, reason = MovementTest()
        if not success then
            TriggerServerEvent("drez_antirpfmods/abort", "Player aborted test Anti-Movement with reason: " .. tostring(reason))
        else
            table.insert(testResults, {name = "Anti-Movement", passed = reason and "not detected" or "mods detected"})
        end
    end

    StopAudioScene("MP_LEADERBOARD_SCENE")
    StopAudioScene("MP_LOBBY_SCENE")
    isPlayerReady = false
    SetPlayerControl(PlayerId(), true)

    SetEntityCoords(PlayerPedId(), originalCoords.x, originalCoords.y, originalCoords.z)
    NetworkResurrectLocalPlayer(originalCoords.x, originalCoords.y, originalCoords.z, 180, 0, false)
    RemovePlatform()

    if not isAbortTriggered then
        TriggerServerEvent("drez_antirpfmods/end", testResults)
    end

    while not isTestActive do Wait(0) end
    DoScreenFadeIn(1000)
    while not IsScreenFadedIn() do Wait(0) end

    TEST_RUNNING = false
end

if Config.NoRelations then
    CreateThread(RunAntiRPFTest)
end

exports("RunTest", function()
    CreateThread(RunAntiRPFTest)
end)

return "LOAD_AFTER_CODE"
