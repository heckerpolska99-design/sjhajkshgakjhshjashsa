local Platforms = {
    {name = "floor", model = 487569140, coords = vec3(2421.05, 1417.16, -96.51), spawnByDefault = true},
    {name = "wall", model = 2108146567, coords = vec3(2421.05, 1417.16, -92.51), spawnByDefault = true},
    {name = "stairs", model = -884803471, coords = vec4(2422.49, 1412.65, -95.51, -270.83), spawnByDefault = false}
}

-- Spawns a single object
local function SpawnObject(obj)
    if not (IsModelValid(obj.model) and IsModelInCdimage(obj.model)) then
        return false, "Platform object " .. tostring(obj.name) .. " is invalid"
    end

    RequestStreamedModel(obj.model)
    local entity = CreateObject(obj.model, obj.coords.x, obj.coords.y, obj.coords.z, false, true, false)
    obj.entity = entity

    while not DoesEntityExist(entity) do
        Wait(0)
    end

    if obj.coords.w then
        SetEntityHeading(entity, obj.coords.w)
    end
    FreezeEntityPosition(entity, true)
    SetBlockingOfNonTemporaryEvents(entity, true)
    SetModelAsNoLongerNeeded(obj.model)
end

-- Spawns all default platform objects
local function SpawnPlatform()
    for _, obj in pairs(Platforms) do
        if obj.spawnByDefault then
            SpawnObject(obj)
        end
    end
end

-- Removes all platform objects near their original positions
local function RemovePlatform()
    for _, obj in pairs(Platforms) do
        if obj.entity and DoesEntityExist(obj.entity) then
            DeleteObject(obj.entity)
        end
    end

    for _, entity in pairs(GetGamePool("CObject")) do
        if DoesEntityExist(entity) then
            for _, obj in pairs(Platforms) do
                if GetEntityModel(entity) == obj.model and #(GetEntityCoords(entity) - vec3(obj.coords.x, obj.coords.y, obj.coords.z)) <= 80.0 then
                    DeleteEntity(entity)
                end
            end
        end
    end
end

-- Remove a specific platform object by name
local function RemovePlatformObject(name)
    for _, obj in pairs(Platforms) do
        if obj.entity and DoesEntityExist(obj.entity) and obj.name == name then
            DeleteObject(obj.entity)
            DeleteEntity(obj.entity)
            break
        end
    end
end

-- Adds (spawns) a specific platform object by name
local function AddPlatformObject(name)
    for _, obj in pairs(Platforms) do
        if obj.name == name then
            SpawnObject(obj)
            break
        end
    end
end

-- Cleanup on resource stop
AddEventHandler("onResourceStop", function(resourceName)
    if resourceName == GetCurrentResourceName() then
        RemovePlatform()
        for _, vehicle in pairs(GetGamePool("CVehicle")) do
            DeleteEntity(vehicle)
        end
    end
end)

-- Expose functions
SpawnObject = SpawnObject
SpawnPlatform = SpawnPlatform
RemovePlatform = RemovePlatform
RemovePlatformObject = RemovePlatformObject
AddPlatformObject = AddPlatformObject
