-- Returns the water height at a specific coordinate
local function DoesPlayerHaveWater()
    local x, y, z = -2031.172, -1147.077, -38.55845
    local waterHeight = GetWaterHeight(x, y, z)
    return waterHeight
end

DoesPlayerHaveWater = DoesPlayerHaveWater
