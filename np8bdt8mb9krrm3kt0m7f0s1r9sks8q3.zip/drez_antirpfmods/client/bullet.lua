local function BulletPenTest()
    local playerPed = PlayerPedId()
    local playerCoords = Config.BulletPenTest.Player
    local pedData = Config.BulletPenTest.Ped
    local vehicleData = Config.BulletPenTest.Vehicle
    local vehicleModel = Config.BulletPenTest.VehicleModel
    local weaponModel = Config.WeaponModel

    -- Set player position and heading
    SetEntityCoords(playerPed, playerCoords.x, playerCoords.y, playerCoords.z)
    SetEntityHeading(playerPed, playerCoords.w)

    -- Spawn test ped
    local testPed, pedError = SpawnPed(pedData)
    if not testPed then
        DeletePed(testPed)
        return false, pedError
    end

    -- Equip weapon
    SpawnWeapon()

    -- Shoot at ped 2 times
    for i = 1, 2 do
        local boneCoords = GetPedBoneCoords(testPed, 31086, 0.0, 0.0, 0.0)
        SetPedShootsAtCoord(playerPed, boneCoords, true)
        Wait(800)
    end

    -- Clear player tasks
    ClearPedTasks(playerPed)
    ClearPedTasksImmediately(playerPed)

    -- Check if ped died
    if IsPedFatallyInjured(testPed) and DoesEntityExist(testPed) then
        DeleteEntity(vehicleData)
        DeleteEntity(testPed)
        return "wall", false
    end

    -- Remove wall object
    RemovePlatformObject("wall")

    -- Spawn vehicle and put ped inside
    local testVehicle, vehicleError = SpawnVehicle(vehicleModel, vehicleData)
    if not testVehicle then
        DeletePed(testPed)
        DeletePed(testVehicle)
        return false, vehicleError
    end

    SetPedIntoVehicle(testPed, testVehicle, -1)
    while GetPedInVehicleSeat(testVehicle, -1) ~= testPed do
        Wait(300)
        SetPedIntoVehicle(testPed, testVehicle, -1)
    end

    Wait(200)

    -- Shoot at ped in vehicle 2 times
    for i = 1, 2 do
        local boneCoords = GetPedBoneCoords(testPed, 31086, 0.0, 0.0, 0.0)
        SetPedShootsAtCoord(playerPed, boneCoords, true)
        Wait(800)
    end

    -- Remove weapon and clear tasks again
    RemoveWeaponFromPed(playerPed, weaponModel)
    ClearPedTasks(playerPed)
    ClearPedTasksImmediately(playerPed)

    -- Check if ped died inside vehicle
    if IsPedFatallyInjured(testPed) and DoesEntityExist(testPed) then
        DeleteEntity(testVehicle)
        DeleteEntity(testPed)
        return "car", false
    end

    -- Cleanup
    DeleteEntity(testVehicle)
    DeleteEntity(testPed)

    return true, true
end

BulletPenTest = BulletPenTest
