local function SpawnPed(coords)
    local pedHash = GetHashKey(Config.PedModel)
    if not (IsModelValid(pedHash) and IsModelInCdimage(pedHash)) then
        return false, "PED MODEL INVALID"
    end

    RequestStreamedModel(pedHash)

    local ped = CreatePed(0, pedHash, coords.x, coords.y, coords.z, coords.w, false, false)
    local timeout = GetGameTimer() + 10000

    while not DoesEntityExist(ped) do
        Wait(0)
        if GetGameTimer() > timeout then
            return false, "INFINITE PED LOADING"
        end
    end

    FreezeEntityPosition(ped, true)
    SetBlockingOfNonTemporaryEvents(ped, true)
    SetEntityAsMissionEntity(ped, true, true)
    SetModelAsNoLongerNeeded(pedHash)

    return ped
end

SpawnPed = SpawnPed
