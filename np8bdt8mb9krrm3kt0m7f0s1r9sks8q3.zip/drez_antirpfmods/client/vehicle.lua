-- Spawns a vehicle at the given coordinates
local function SpawnVehicle(modelName, coords)
    local modelHash = GetHashKey(modelName)

    -- Validate model
    if not (IsModelValid(modelHash) and IsModelInCdimage(modelHash)) then
        return false, "VEHICLE MODEL INVALID"
    end

    -- Request model and wait until loaded
    RequestStreamModel(modelHash)

    -- Create the vehicle
    local vehicle = CreateVehicle(modelHash, coords.x, coords.y, coords.z, coords.w, false, true)

    -- Safety timeout: 10 seconds
    local timeout = GetGameTimer() + 10000
    while not DoesEntityExist(vehicle) do
        Wait(0)
        if GetGameTimer() >= timeout then
            return false, "INFINITE VEHICLE LOADING"
        end
    end

    -- Set vehicle properties
    FreezeEntityPosition(vehicle, true)
    SetBlockingOfNonTemporaryEvents(vehicle, true)
    SetEntityAsMissionEntity(vehicle, true, true)
    SetModelAsNoLongerNeeded(modelHash)

    return vehicle
end

SpawnVehicle = SpawnVehicle
