local weaponComponents = {
    119648377, -696561875, 834974250, 614078421, -884429072, 283556395, 643254679, 889808635,
    -1101075946, -1323216997, -1614924820, -1861183855, -91250417, -1899902599, -197857404,
    -2112517305, -503336118, -691692330, -781249480, -942267867, -1796727865, -2034401422,
    580369945, -640439150, -1928132688, -1152981993, 1967214384, 202788691, 899381934,
    2076495324, -1657815255, -1439939148, -1596416958, -767279652, -1135289737, -1023114086
}

local function WeaponComponentsDamageDetection()
    for _, componentHash in pairs(weaponComponents) do
        local damageModifier = GetWeaponComponentDamageModifier(componentHash)
        local accuracyModifier = GetWeaponComponentAccuracyModifier(componentHash)
        if damageModifier > 1.1 or accuracyModifier > 1.2 then
            return false
        end
    end
    return true
end

WeaponComponentsDamageDetection = WeaponComponentsDamageDetection
