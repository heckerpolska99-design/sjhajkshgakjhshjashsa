local function LoadCollisions()
    local retries = 20
    local playerPed = PlayerPedId()
    local testCoords = Config.TestPlace

    SetEntityCoords(playerPed, testCoords.x, testCoords.y, testCoords.z)

    while true do
        if HasCollisionLoadedAroundEntity(playerPed) then
            break
        end

        RequestCollisionAtCoord(testCoords.x, testCoords.y, testCoords.z)
        SetEntityCoords(playerPed, testCoords.x, testCoords.y, testCoords.z)
        Wait(300)

        retries = retries - 1
        if retries <= 0 then
            break
        end
    end

    SetEntityCoords(playerPed, testCoords.x, testCoords.y, testCoords.z)
end

LoadCollisions = LoadCollisions
