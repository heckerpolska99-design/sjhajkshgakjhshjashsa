local function QuickReloadMods()
    -- Give weapon
    SpawnWeapon()

    -- Force ped to shoot at zero coordinate a couple of times
    for i = 1, 2 do
        SetPedShootsAtCoord(PlayerPedId(), 0.0, 0.0, 0.0, true)
        Wait(800)
    end

    -- Reload weapon
    TaskReloadWeapon(PlayerPedId())

    -- Wait until the reload task is active
    while not GetIsTaskActive(PlayerPedId(), 298) do
        Wait(0)
    end

    local startTime = GetGameTimer()

    -- Wait while ped is still reloading
    while GetIsTaskActive(PlayerPedId(), 298) and IsPedReloading(PlayerPedId()) do
        Wait(0)
    end

    local elapsed = GetGameTimer() - startTime

    -- Remove weapon and clear tasks
    RemoveWeaponFromPed(PlayerPedId(), Config.WeaponModel)
    ClearPedTasks(PlayerPedId())
    ClearPedTasksImmediately(PlayerPedId())

    -- Return success and whether reload took longer than 1 second
    return true, elapsed > 1000
end

QuickReloadMods = QuickReloadMods
