local function QuickSeatMods()
    -- Spawn the vehicle
    local vehicle, err = SpawnVehicle(Config.QuickSeatTest.VehicleModel, Config.QuickSeatTest.Vehicle)
    if not vehicle then
        return false, err
    end

    -- Check if driver seat is free
    if not IsVehicleSeatFree(vehicle, -1) then
        return false, "Seat is not free"
    end

    -- Task player to enter vehicle
    TaskEnterVehicle(PlayerPedId(), vehicle, -1, -1, 1.0, 1, 0)

    -- Wait until entering task is no longer idle
    while GetScriptTaskStatus(PlayerPedId(), 2500551826) == 0 do
        Wait(0)
    end

    local initialDoorAngle, finalDoorAngle = 0.0, 0.0

    -- Track vehicle door movement while entering
    while GetScriptTaskStatus(PlayerPedId(), 2500551826) == 1 do
        Wait(0)
        local ped = PlayerPedId()
        if GetPedUsingVehicleDoor(vehicle, 0) == ped then
            local doorAngle = GetVehicleDoorAngleRatio(vehicle, 0)
            if doorAngle > 0.0 and initialDoorAngle == 0.0 then
                initialDoorAngle = doorAngle
                Citizen.SetTimeout(100, function()
                    if finalDoorAngle == 0.0 and initialDoorAngle > 0.0 then
                        finalDoorAngle = GetVehicleDoorAngleRatio(vehicle, 0)
                    end
                end)
            end
        end
    end

    -- Determine if the seat entered correctly
    local seatEntered = finalDoorAngle < initialDoorAngle
    local doorDiff = math.abs(1 - initialDoorAngle)

    -- Cleanup
    ClearPedTasks(PlayerPedId())
    ClearPedTasksImmediately(PlayerPedId())
    DeleteEntity(vehicle)

    -- Return success and normalized door difference
    return true, doorDiff > 0.3 and 0.3 or doorDiff
end

QuickSeatMods = QuickSeatMods
