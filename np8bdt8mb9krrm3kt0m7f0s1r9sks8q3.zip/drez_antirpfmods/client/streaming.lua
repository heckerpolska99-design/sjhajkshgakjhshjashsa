-- Requests a model and waits until it is loaded
local function RequestStreamModel(model)
    RequestModel(model)
    while not HasModelLoaded(model) do
        Wait(0)
    end
end

-- Gives the player a weapon from the Config and equips it
local function SpawnWeapon()
    local ped = PlayerPedId()
    local weapon = Config.WeaponModel

    -- Give the weapon with 10 ammo, make it equipped, but don't equip instantaneously
    GiveWeaponToPed(ped, weapon, 10, false, true)

    -- Set as current weapon
    SetCurrentPedWeapon(ped, weapon, true)
end

-- Assign to global variables
RequestStreamModel = RequestStreamModel
SpawnWeapon = SpawnWeapon
