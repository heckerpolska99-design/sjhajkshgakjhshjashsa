local function DetectNoBushes()
    for _, modelName in pairs(Config.BushModels) do
        local modelHash = GetHashKey(modelName)
        if not IsModelInCdimage(modelHash) then
            return modelName
        end
    end
    return false
end

DetectNoBushes = DetectNoBushes
