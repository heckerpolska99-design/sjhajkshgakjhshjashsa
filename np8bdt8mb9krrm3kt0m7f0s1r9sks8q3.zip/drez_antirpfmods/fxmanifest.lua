fx_version 'cerulean'
game 'gta5'
lua54 'yes'
author "leaked by xaries1g"
description "discord.gg/cfxmafia"  


client_scripts {
    "config/client.config.lua",
    "client/*.lua",
}

server_scripts {
    "config/client.config.lua",
    "config/server.config.lua",
    "server/*.lua",
}