CreateThread(function()
    assert(type(Config.Log) == "boolean", "^1[WARNING] ^0Config.^5Log^0 is not a boolean")
    assert(type(Config.LogPlayer) == "boolean", "^1[WARNING] ^0Config.^5LogPlayer^0 is not a boolean")
    assert(type(Config.KickPlayer) == "boolean", "^1[WARNING] ^0Config.^5KickPlayer^0 is not a boolean")
    assert(type(Config.BanPlayer) == "boolean", "^1[WARNING] ^0Config.^5BanPlayer^0 is not a boolean")
    assert(type(Config.LogMessage) == "string", "^1[WARNING] ^0Config.^5LogMessage^0 is not a string")
    assert(type(Config.LogWebhook) == "string", "^1[WARNING] ^0Config.^5LogWebhook^0 is not a string")
    assert(type(Config.BanFunction) == "function", "^1[WARNING] ^0Config.^5BanEvent^0 is not a function")
    assert(type(Config.BucketRange) == "table", "^1[WARNING] ^0Config.^5BucketRange^0 is not a table")
    assert(type(Config.BucketRange[1]) == "number", "^1[WARNING] ^0Config.^5BucketRange^0 is not a table of numbers")
    assert(type(Config.BucketRange[2]) == "number", "^1[WARNING] ^0Config.^5BucketRange^0 is not a table of numbers")
    assert(type(Config.NoRelations) == "boolean", "^1[WARNING] ^0Config.^5NoRelations^0 is not a boolean")
    assert(type(Config.SyncHandle) == "function", "^1[WARNING] ^0Config.^5SyncHandle^0 is not a function")

    local author = "Drez https://github.com/Drezx | https://drez.tebex.io/"
    if GetResourceMetadata(GetCurrentResourceName(), "author", 0) ~= author then
        return print("^1[WARNING]^0 Please leave author credits as original. We do not tolerate ^1plagiarism^0!")
    end

    print("^2[STARTED]^0 drez_antirpfmods ^2passed^0 all checks")
    Events.Run()
end)
