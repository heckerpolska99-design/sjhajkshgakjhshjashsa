if not Config.AntiSuperpunch then return end

AddEventHandler("weaponDamageEvent", function(playerId, eventData)
    if eventData.weaponType ~= 2725352035 then return end
    if eventData.weaponDamage <= 500 then return end
    if eventData.damageFlags ~= 10 and eventData.damageFlags ~= 522 then return end

    CancelEvent()

    local typeDetected = eventData.damageFlags == 10 and "vehicle" or "ped"
    local player = tonumber(playerId)

    if Config.Log then
        print("^5[drez_antirpfmods]^0 Player ^1[" .. player .. "] " .. GetPlayerName(player) .. " ^0is using superpunch mod on " .. typeDetected)
    end

    if Config.LogPlayer then
        LogWebhook(player, "Anti-Superpunch: mods detected")
    end

    if Config.BanPlayer then
        Config.BanFunction(player, {{name = "Anti-Superpunch", passed = "mods detected"}})
    end

    if Config.KickPlayer then
        DropPlayer(player, "drez_antirpfmods: " .. tostring(Config.KickMessage))
    end
end)
