local PlayerBuckets = {}

Events = {}

local function AllPassed(results)
    for _, v in pairs(results) do
        if v.passed ~= "not detected" then
            return false
        end
    end
    return true
end

local function GetDetectedNames(results)
    local str = ""
    for _, v in pairs(results) do
        if v.passed ~= "not detected" then
            str = str .. v.name .. "\n "
        end
    end
    return str:sub(1, #str - 2)
end

function Events.Run()
    RegisterNetEvent("drez_antirpfmods/start", function()
        local src = source
        if src == 0 then return end
        local bucket = GetFreeBucket()
        PlayerBuckets[src] = GetPlayerRoutingBucket(src)
        SetPlayerRoutingBucket(src, bucket)
        TriggerClientEvent("drez_antirpfmods/syncBucket", src)
    end)

    RegisterNetEvent("drez_antirpfmods/end", function(results)
        local src = source
        if src == 0 then return end

        local origBucket = PlayerBuckets[src] or 0
        SetPlayerRoutingBucket(src, origBucket)
        PlayerBuckets[src] = nil

        if not AllPassed(results) then
            local detected = GetDetectedNames(results)
            if Config.Log then
                print("^5[drez_antirpfmods]^0 Player ["..src.."] "..GetPlayerName(src).." is using RPF Mods\n"..detected)
            end
            if Config.LogPlayer then LogWebhook(src, detected) end
            if Config.BanPlayer then Config.BanFunction(src, results) end
            if Config.KickPlayer then Config.KickFunction(src, detected) end
        end

        TriggerClientEvent("drez_antirpfmods/syncBucket", src)
    end)

    RegisterNetEvent("drez_antirpfmods/abort", function(reason)
        local src = source
        if src == 0 or type(reason) ~= "string" then return end
        SetPlayerRoutingBucket(src, PlayerBuckets[src])
        if Config.Log then
            print("^5[drez_antirpfmods]^0 Player ["..src.."] "..GetPlayerName(src).." aborted RPF Mods test with reason: "..reason)
        end
        PlayerBuckets[src] = nil
        TriggerClientEvent("drez_antirpfmods/syncBucket", src)
    end)

    AddEventHandler("playerDropped", function()
        local src = source
        PlayerBuckets[src] = nil
    end)
end
